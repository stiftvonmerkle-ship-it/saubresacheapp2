SAUBRESACHE DETAILINGOS - ANDROID DUMMY

Das Projekt ist eine native Android-Wrapper-App fuer die lokale SaubreSache Fahrzeugakte.

Bereits integriert:
- echte Android-App-Oberflaeche via WebView
- kompletter bestehender DetailingOS-Workflow
- IndexedDB bleibt lokal auf dem Handy
- Kamera/Galerie fuer Fahrzeugfotos
- PDF-Erstellung in der App
- PDF speichern nach Downloads/SaubreSache
- PDF direkt ueber Android-Teilen an WhatsApp/Gmail/etc.
- eigener App-Name und App-Icon
- Google-Login fuer diesen Dummy bewusst deaktiviert; kommt spaeter sauber mit OAuth.

APK in Android Studio bauen:
1. Projektordner oeffnen.
2. Android Studio installiert erforderliches SDK automatisch.
3. Build > Build APK(s).
4. APK liegt unter app/build/outputs/apk/debug/app-debug.apk

Paketname: de.saubresache.detailingos
Min Android: Android 10 (API 29)
