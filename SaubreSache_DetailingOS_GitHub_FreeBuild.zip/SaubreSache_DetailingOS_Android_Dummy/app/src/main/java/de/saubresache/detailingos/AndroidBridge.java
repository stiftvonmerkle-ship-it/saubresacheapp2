package de.saubresache.detailingos;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class AndroidBridge {
    private final MainActivity activity;

    AndroidBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void savePdf(String fileName, String base64Data) {
        activity.runOnUiThread(() -> {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                ContentResolver resolver = activity.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, sanitize(fileName));
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaubreSache");
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Download konnte nicht angelegt werden");
                try (OutputStream os = resolver.openOutputStream(uri)) {
                    if (os == null) throw new IllegalStateException("Datei konnte nicht geöffnet werden");
                    os.write(bytes);
                }
                Toast.makeText(activity, "PDF gespeichert: Downloads/SaubreSache", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(activity, "PDF konnte nicht gespeichert werden: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @JavascriptInterface
    public void sharePdf(String fileName, String base64Data, String message) {
        activity.runOnUiThread(() -> {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                File dir = new File(activity.getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                File pdf = new File(dir, sanitize(fileName));
                try (FileOutputStream fos = new FileOutputStream(pdf)) {
                    fos.write(bytes);
                }
                Uri uri = AppFileProvider.getUriForFile(activity, "de.saubresache.detailingos.fileprovider", pdf);
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("application/pdf");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(Intent.createChooser(share, "Fahrzeugprotokoll senden"));
            } catch (Exception e) {
                Toast.makeText(activity, "Teilen konnte nicht geöffnet werden: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @JavascriptInterface
    public void toast(String message) {
        activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
    }

    private String sanitize(String name) {
        String n = name == null || name.trim().isEmpty() ? "SaubreSache_Protokoll.pdf" : name.trim();
        n = n.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }
}
