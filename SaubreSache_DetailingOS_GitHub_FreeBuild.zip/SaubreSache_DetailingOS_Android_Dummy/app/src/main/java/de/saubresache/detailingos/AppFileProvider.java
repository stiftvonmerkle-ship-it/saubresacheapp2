package de.saubresache.detailingos;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public class AppFileProvider extends ContentProvider {
    private static final String AUTHORITY = "de.saubresache.detailingos.fileprovider";

    public static Uri getUriForFile(Context context, String authority, File file) {
        if (!AUTHORITY.equals(authority)) throw new IllegalArgumentException("Unknown authority");
        String path;
        File cache = context.getCacheDir();
        try {
            String base = cache.getCanonicalPath();
            String full = file.getCanonicalPath();
            if (!full.startsWith(base + File.separator)) throw new IllegalArgumentException("File outside cache");
            path = full.substring(base.length());
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
        return new Uri.Builder().scheme("content").authority(AUTHORITY).encodedPath(path).build();
    }

    @Override public boolean onCreate() { return true; }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (!AUTHORITY.equals(uri.getAuthority())) throw new FileNotFoundException("Bad authority");
        try {
            String rel = uri.getPath();
            if (rel == null) throw new FileNotFoundException("Missing path");
            while (rel.startsWith("/")) rel = rel.substring(1);
            File f = new File(getContext().getCacheDir(), rel);
            String base = getContext().getCacheDir().getCanonicalPath();
            String full = f.getCanonicalPath();
            if (!full.startsWith(base + File.separator)) throw new FileNotFoundException("Bad path");
            return f;
        } catch (Exception e) {
            throw new FileNotFoundException(e.getMessage());
        }
    }

    @Override public String getType(Uri uri) {
        String p = uri.getPath();
        return p != null && p.toLowerCase().endsWith(".pdf") ? "application/pdf" : "image/jpeg";
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols);
        try {
            File f = resolve(uri);
            MatrixCursor.RowBuilder r = c.newRow();
            for (String col : cols) {
                if (OpenableColumns.DISPLAY_NAME.equals(col)) r.add(f.getName());
                else if (OpenableColumns.SIZE.equals(col)) r.add(f.length());
                else r.add(null);
            }
        } catch (Exception ignored) {}
        return c;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        int flags = mode != null && mode.contains("w") ? ParcelFileDescriptor.MODE_READ_WRITE : ParcelFileDescriptor.MODE_READ_ONLY;
        return ParcelFileDescriptor.open(f, flags);
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { try { return resolve(uri).delete() ? 1 : 0; } catch (Exception e) { return 0; } }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
}
